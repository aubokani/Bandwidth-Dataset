Author: Jun Yao
Email: jyao@cse.unsw.edu.au
Contact: 
	School of Computer Science & Engineering,
	University of New South Wales,
	Sydney 2052,
	Australia

Alternatively, contact Salil Kanhere or Mahbub Hassan {salilk,mahbub}@cse.unsw.edu.au

Summary
	Traces of measured network available bandwidth (in Kbps) in text format, 
	collected from our mobile measurment study from a 23Km route in Sydney, Australia.

Number of Traces: 
	71 (trip #1-#71)

Directories:
	hsdpa1: contains bandwidth trace from HSDPA network provider 1
	hsdpa2: contains bandwidth trace from HSDPA network provider 2
	iburst: contains bandwidth trace from iBurst network provider

Sample Frequency:
	If available, roughly 1 sample for every 200m of the road (moving) or 10 second (stationary). 

Format:
	The processed text data files consists of the following information:
	<time> <latitude> <logitude> <bandwidth (Kbps)>

	